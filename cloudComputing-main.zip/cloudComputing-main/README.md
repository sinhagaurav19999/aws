# cloudComputing
#In this task we are going to run a operating system(in our case Windows) using cloud computing we will be using AWS(Amazon Web Services) for this task how every one can also use Microsoft Azure
![image](https://user-images.githubusercontent.com/50267963/130200499-40d25059-afcb-430d-a9e8-d8db3bb33d1a.png)
